﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    /// <summary>
    /// ////////to the level of coding i know i have implemented a use of an arrar list
    /// </summary>
    static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        while (true)
        {
            ////below is the code that will appear as an interface when the program starts running
            ///
            Console.WriteLine("**********************************************");
            Console.WriteLine(" 1. New Recipe Entry");
            Console.WriteLine(" 2. Display Recipes");
            Console.WriteLine(" 3. Reset ");
            Console.WriteLine(" 4. Clear Recipes");
            Console.WriteLine(" 5. Recipe Scale");
            Console.WriteLine(" 6. Exit");
            Console.WriteLine("***********************************************");

            string set = Console.ReadLine();

            switch (set)
            {
                case "1":
                    UserInput();
                    break;
                case "2":
                    DisplayOption();
                    break;
                case "3":
                    ResetOption();
                    break;
                case "4":
                    ClearOption();
                    break;
                case "5":
                    ScaleOption();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            Console.WriteLine();
        }
    }
    ///method containing what the user must enter for the recipe//
    static void UserInput()
    {
        Recipe recipe = new Recipe();

        Console.Write(" Name of the recipe: ");
        recipe.Name = Console.ReadLine();

        recipe.Ingredients = new List<Ingredient>();

        while (true)
        {
            Ingredient ingredient = new Ingredient();

            Console.Write(" Name of the ingredient( Complete): ");
            //////to add recipe successfully type complete in the name of ingredients section/////////////////
            string ingredientName = Console.ReadLine();

            if (ingredientName == "Complete")
                break;

            ingredient.Name = ingredientName;

            Console.Write(" Calories: ");
            ingredient.Calories = int.Parse(Console.ReadLine());

            Console.Write(" Food Group: ");
            ingredient.FoodGroup = Console.ReadLine();

            recipe.Ingredients.Add(ingredient);
        }

        recipes.Add(recipe);

        Console.WriteLine("Recipe added successfully!");
    }
/// <summary>
/// /////////////////////this method has code that has the ability to display the whole recipe or recipes depending on how many there are
/// </summary>
    static void DisplayOption()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes found!");
            return;
        }

        recipes = recipes.OrderBy(r => r.Name).ToList();

        foreach (var recipe in recipes)
        {
            Console.WriteLine($"Recipe Name: {recipe.Name}");
            Console.WriteLine("Ingredients:");

            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"- {ingredient.Name}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}");
            }

            Console.WriteLine($"Total Calories: {recipe.TotalCalories}");

            if (recipe.TotalCalories > 300)
            {
                Console.WriteLine(" This recipe is above 300 calories!");
                NotifyUserExceedingCalories(recipe);
            }

            Console.WriteLine();
        }
    }
    /// <summary>
    /// this displays what exactly is being scaled to be precise the calories are being scaled since there are the only unit of measurement
    /// </summary>
    static void ScaleOption()
    {
        Console.WriteLine("Enter the recipe name to scale: ");
        string recipeName = Console.ReadLine();

        var recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found!");
            return;
        }

        Console.WriteLine("Enter a scale of 0.5, 2, or 3");
        double scale = Convert.ToDouble(Console.ReadLine());

        recipe.ScaleIngredients(scale);

        Console.WriteLine("Recipe scaled successfully!");
    }
    /// <summary>
    /// ////here we have the reset method which resets every change made to the recipe you have done
    /// </summary>
    static void ResetOption()
    {
        Console.WriteLine("Enter the recipe name to reset: ");
        string recipeName = Console.ReadLine();

        var recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found!");
            return;
        }

        recipe.ResetIngredients();

        Console.WriteLine("Recipe reset successfully!");
    }

    static void ClearOption()
    {
        Console.WriteLine("Enter the recipe name to clear: ");
        string recipeName = Console.ReadLine();

        var recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found!");
            return;
        }

        recipes.Remove(recipe);

        Console.WriteLine("Recipe cleared ");
    }

    static void NotifyUserExceedingCalories(Recipe recipe)
    {
        Console.WriteLine($"The recipe '{recipe.Name}' exceeds 300 calories!");
    }
}
/// <summary>
/// ////////the classes created below were to retrieve what code was done above so the program can run smoothly
/// </summary>
class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }

    public int TotalCalories
    {
        get { return Ingredients.Sum(i => i.Calories); }
    }

    public void ScaleIngredients(double scale)
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Calories = (int)(ingredient.Calories * scale);
        }
    }

    public void ResetIngredients()
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Calories /= 2;
        }
    }
}

class Ingredient
{
    public string Name { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
}