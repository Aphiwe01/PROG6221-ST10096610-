﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace Recipes
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the recipes list
            recipes = new List<Recipe>();

            // Set the BackgroundBrush resource
            ImageBrush backgroundBrush = new ImageBrush(new BitmapImage(new Uri("C:\\Users\\aphiw\\source\\repos\\Recipes\\Images\\istockphoto-1382277883-612x612.jpg")));
                       
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the input values
            string foodGroup = FoodGroupTextBox.Text;
            string recipeName = RecipeNameTextBox.Text;
            int calories = 0;
            string steps = StepsTextBox.Text; // New line

            // Validate the input values
            if (string.IsNullOrWhiteSpace(foodGroup) || string.IsNullOrWhiteSpace(recipeName) || !int.TryParse(CaloriesTextBox.Text, out calories) || string.IsNullOrWhiteSpace(steps)) // Updated line
            {
                MessageBox.Show("Invalid input! Please enter valid values for all fields.");
                return;
            }

            // Create a new Recipe object
            Recipe recipe = new Recipe(foodGroup, recipeName, calories, IngredientTextBox.Text, steps); // Updated line

            // Add the recipe to the list
            recipes.Add(recipe);

            // Clear the input fields
            FoodGroupTextBox.Clear();
            IngredientTextBox.Clear();
            CaloriesTextBox.Clear();
            RecipeNameTextBox.Clear();
            StepsTextBox.Clear(); // New line

            // Update the recipe list in the ListBox
            UpdateRecipeListBox();

            // Show success message
            MessageBox.Show("Recipe added successfully.");

            // Check if calories are above 300 and show appropriate message
            if (calories > 300)
            {
                MessageBox.Show("This recipe is above 300 calories!!!!!");
            }
        }

        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Get the selected recipe
            Recipe selectedRecipe = RecipeListBox.SelectedItem as Recipe;

            if (selectedRecipe != null)
            {
                // Display the details of the selected recipe
                RecipeNameTextBlock.Text = "Recipe #" + (RecipeListBox.SelectedIndex + 1);
                FoodGroupTextBlock.Text = selectedRecipe.FoodGroup;
                IngredientTextBlock.Text = selectedRecipe.Ingredient;
                CaloriesTextBlock.Text = selectedRecipe.Calories.ToString();
            }
            else
            {
                // Clear the details if no recipe is selected
                RecipeNameTextBlock.Text = "";
                FoodGroupTextBlock.Text = "";
                IngredientTextBlock.Text = "";
                CaloriesTextBlock.Text = "";
            }
        }

        private void UpdateRecipeListBox()
        {
            // Clear the ListBox
            RecipeListBox.Items.Clear();

            // Add the recipes to the ListBox
            foreach (Recipe recipe in recipes)
            {
                RecipeListBox.Items.Add(recipe);
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear the recipe list and update the ListBox
            recipes.Clear();
            UpdateRecipeListBox();

            // Clear the recipe details
            RecipeListBox.SelectedIndex = -1;
            RecipeNameTextBlock.Text = "";
            FoodGroupTextBlock.Text = "";
            IngredientTextBlock.Text = "";
            CaloriesTextBlock.Text = "";

            // Show success message
            MessageBox.Show("Recipe reset successfully.", "Success");
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear the input fields
            FoodGroupTextBox.Clear();
            IngredientTextBox.Clear();
            CaloriesTextBox.Clear();
            RecipeNameTextBox.Clear();

            // Show success message
            MessageBox.Show("Recipe cleared successfully.", "Success");
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected recipe
            Recipe selectedRecipe = RecipeListBox.SelectedItem as Recipe;

            if (selectedRecipe != null)
            {
                // Scale the recipe by 2 or 3
                selectedRecipe.Scale(2); // Scale by 2, you can change this to 3 if needed

                // Update the recipe details in the ListBox
                RecipeListBox.Items.Refresh();

                // Show success message
                MessageBox.Show("Recipe scaled successfully.", "Success");
            }
            else
            {
                // No recipe selected, show error message
                MessageBox.Show("Please select a recipe to scale.", "Error");
            }
        }

        private void DisplayRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            // Display the recipes in a MessageBox
            StringBuilder sb = new StringBuilder();
            foreach (Recipe recipe in recipes)
            {
                sb.AppendLine(recipe.ToString());
            }
            MessageBox.Show(sb.ToString(), "Recipes");
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // Close the application
            Application.Current.Shutdown();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the search term
            string searchTerm = SearchTextBox.Text;

            // Search for recipes based on recipe name
            List<Recipe> searchResults = recipes.Where(r => r.RecipeName.Equals(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();

            if (searchResults.Count == 0)
            {
                // Show not found message
                MessageBox.Show("Recipe not found.", "Not Found");
            }
            else
            {
                // Display the search results in the ListBox
                RecipeListBox.Items.Clear();
                foreach (Recipe recipe in searchResults)
                {
                    RecipeListBox.Items.Add(recipe);
                }
            }
        }
    }

    public class Recipe
    {
        public string FoodGroup { get; set; }
        public string Ingredient { get; set; }
        public int Calories { get; set; }
        public string RecipeName { get; set; }
        public string Steps { get; set; } // Added line

        public Recipe(string foodGroup, string recipeName, int calories, string ingredient, string steps) // Updated line
        {
            FoodGroup = foodGroup;
            RecipeName = recipeName;
            Calories = calories;
            Ingredient = ingredient;
            Steps = steps; // Added line
        }

        public void Scale(int factor)
        {
            Calories *= factor;
        }

        public override string ToString()
        {
            return "Recipe - Name: " + RecipeName + ", Food Group: " + FoodGroup + ", Ingredient: " + Ingredient + ", Calories: " + Calories + ", Steps: " + Steps;
        }
    }
}
